import reflex as rx

config = rx.Config(
    app_name="ZenQ",
    # api_url="https://d8642c9b-ed91-4f20-95ba-e388da7ec848.fly.dev"
)