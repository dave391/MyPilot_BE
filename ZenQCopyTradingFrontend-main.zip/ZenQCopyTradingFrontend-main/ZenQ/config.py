# base_url = "http://127.0.0.1:4000"
base_url = "https://zenqcopytradingbackend.onrender.com"
disable_buttons = False

alert_text = """Attenzione: La Performance passate non garantisce risultati fururi. Non Dovreste affidarvi a nessuna performance passate come garanzia di risultati futuri."""
light_name="Light"
light_desc= """Questo insieme di algoritmi ha due funzioni principali:

- Acquista token che scendono di prezzo sotto i supporti recenti, in modo da creare un accumulo a prezzi decrescenti, per poi rivendere alla prima risalita.

- Acquista token che hanno una tendenza positiva grazie ad un insieme di algoritmi che classificano la tendenza, solo i migliori del momento vengono selezionati.

l'algoritmo vende non appena i prezzi salgono con due obiettivi 0.8% e 1.5%, generando quindi tante piccole trade che accumulano risultati.

Uno stop del 10% è aggiunto a tutte le trade per evitare situazioni di massimo rischio sul singolo token o su tutto il mercato.
"""

investor_name="Investor"
investor_desc= """Questo insieme di algoritmi ha due funzioni principali:

- Acquista token che scendono di prezzo sotto i supporti recenti, in modo da creare un accumulo a prezzi decrescenti, per poi rivendere alla prima risalita.

- Acquista token che hanno una tendenza positiva grazie ad un insieme di algoritmi che classificano la tendenza, solo i migliori del momento vengono selezionati.

l'algoritmo vende non appena i prezzi salgono con due obiettivi 0.8% e 1.5%, generando quindi tante piccole trade che accumulano risultati.

Uno stop del 10% è aggiunto a tutte le trade per evitare situazioni di massimo rischio sul singolo token o su tutto il mercato.
"""

btc_name="BTC Trend Catcher"
btc_desc= """Questo insieme di algoritmi ha due funzioni principali:

- Acquista token che scendono di prezzo sotto i supporti recenti, in modo da creare un accumulo a prezzi decrescenti, per poi rivendere alla prima risalita.

- Acquista token che hanno una tendenza positiva grazie ad un insieme di algoritmi che classificano la tendenza, solo i migliori del momento vengono selezionati.

l'algoritmo vende non appena i prezzi salgono con due obiettivi 0.8% e 1.5%, generando quindi tante piccole trade che accumulano risultati.

Uno stop del 10% è aggiunto a tutte le trade per evitare situazioni di massimo rischio sul singolo token o su tutto il mercato.
"""

xrp_name="XRP Trend Catcher"
xrp_desc= """Questo insieme di algoritmi ha due funzioni principali:

- Acquista token che scendono di prezzo sotto i supporti recenti, in modo da creare un accumulo a prezzi decrescenti, per poi rivendere alla prima risalita.

- Acquista token che hanno una tendenza positiva grazie ad un insieme di algoritmi che classificano la tendenza, solo i migliori del momento vengono selezionati.

l'algoritmo vende non appena i prezzi salgono con due obiettivi 0.8% e 1.5%, generando quindi tante piccole trade che accumulano risultati.

Uno stop del 10% è aggiunto a tutte le trade per evitare situazioni di massimo rischio sul singolo token o su tutto il mercato.
"""

setup_name ="SETUP"
setup_desc ="""1) **Barra di scorrimento Verde**: Usa il cursore per selezionare quanto allocare all'Algo (massimo 2000 USDC).

2) **STOP LOSS**: Definire la percentuale di **massima perdita** del sistema. Se viene raggiunta l'algo si ferma.

3) **TAKE PROFIT**: Definire la percentuale di **massimo risultato** del sistema. Se viene raggiunta l'algo si ferma.

4) Lasciando "0" nelle box la massima perdita e il massimo risultato non sono impostati.

5) **SUBSCRIBE**: Premi questo pulsante per avviare l’Algo.

6) **UNSUBSCRIBE**: Premi questo pulsante per resettare del conto Demo di questo Algo. Il saldo torna a zero e puoi ripartire. Nota: perderai la cronologia dei risultati precedenti.
"""