"""Navbar component for the app."""

import reflex as rx

from ZenQ import styles


def sidebar(
        *sidebar_links,
) -> rx.Component:
    return rx.vstack(
        rx.hstack(
            rx.color_mode_cond(
                    rx.link(rx.image(src="/logo.svg", height="45px", border_radius="3px"), href='https://zen-q.com/'),
                    rx.link(rx.image(src="/logo_white.svg", height="45px", border_radius="3px"), href='https://zen-q.com/'),
                ),
            width="100%",
            spacing="7",
            align="center",
            margin_x="1em",
        ),
        rx.divider(margin_y="3"),
        rx.vstack(
            *sidebar_links,
            padding_y="1.5em",
            align="center"
        ),
        # rx.divider(margin_y="3"),
        # # rx.spacer(),
        # sidebar_link(text="API Setup", href="/tools", icon="settings"),
        width="7em",
        position="fixed",
        height="100%",
        left="0px",
        top="0px",
        align_items="left",
        # z_index="10",
        backdrop_filter="blur(10px)",
        padding="1em",
    )

def sidebar_link(text: str, href: str, image: str):
    return rx.link(
        rx.flex(
            rx.color_mode_cond(
                rx.image(src=f"/{image}.svg", height="40px", border_radius="3px"),
                rx.image(src=f"/{image}_white.svg", height="40px", border_radius="3px"),
            ),
            text,
            align="center",
            direction="column",
        ),
        href=href,
        width="100%",
        border_radius="8px",
        _hover={
            "background": "rgba(255, 255, 255, 0.1)",
            "backdrop_filter": "blur(10px)",
        },
        padding_bottom="1em"
    )
#
#
# def navbar() -> rx.Component:
#     """The navbar.
#
#     Returns:
#         The navbar component.
#
#     """
#     return rx.el.nav(
#         rx.hstack(
#             sidebar(
#                 sidebar_link(text="Dashboard", href="/dashboard", image="bar_chart"),
#                 sidebar_link(text="Algo", href="/algo", image="algo"),
#             ),
#             rx.box(
#                 # rx.box(background="red",
#                 #        margin_left="10em"),
#
#                         rx.heading("My Pilot", size="7"),
#                 backdrop_filter="blur(100px)",
#                 margin_left="7em"
#             ),
#             rx.spacer(),
#             rx.button("Logout", variant="soft", on_click=rx.redirect("/")),
#             align="center",
#             width="100%",
#             padding_y="1.25em",
#             padding_x=["1em", "1em", "2em"],
#         ),
#         display=["block", "block", "block", "block", "block", "none"],
#         position="sticky",
#         backdrop_filter="blur(10px)",
#         top="0px",
#         z_index="5",
#         border_bottom=styles.border,
#     )

def navbar_icons_item(
    text: str, icon: str, url: str
) -> rx.Component:
    return rx.link(
        rx.hstack(
            rx.icon(icon, color="white"),
            rx.text(text, size="6", weight="bold"),
        ),
        href=url,
    )


def navbar_icons_menu_item(
    text: str, icon: str, url: str
) -> rx.Component:
    return rx.link(
        rx.hstack(
            rx.icon(icon, size=34),
            rx.text(text, size="5", weight="light"),
        ),
        href=url,
    )


def navbar_icons() -> rx.Component:
    return rx.box(
        rx.desktop_only(
            rx.el.nav(
                rx.hstack(
                    sidebar(
                        sidebar_link(text="Dashboard", href="/dashboard", image="bar_chart"),
                        sidebar_link(text="Algo", href="/algo", image="algo"),
                    ),
                    rx.box(
                rx.heading("My Pilot", size="7"),
                            backdrop_filter="blur(100px)",
                            margin_left="7em"
                        ),
                    rx.code("Release 1.3 - Sistemi attivi."),
                    rx.spacer(),
                    rx.button("Logout", variant="soft", on_click=rx.redirect("/")),
                    align="center",
                    width="100%",
                    padding_y="1.25em",
                    padding_x=["1em", "1em", "2em"],
                ),
                display=["block", "block", "block", "block", "block"],
                position="sticky",
                backdrop_filter="blur(10px)",
                top="0px",
                z_index="5",
                border_bottom=styles.border,
            )
        ),
        rx.mobile_and_tablet(
            rx.hstack(
                rx.hstack(
                    rx.image(
                        src="/logo_white.svg",
                        width="2em",
                        height="auto",
                        border_radius="25%",
                    ),
                    rx.heading(
                        "My Pilot", size="6", weight="bold"
                    ),
                    align_items="center",
                ),
                rx.menu.root(
                    rx.menu.trigger(
                        rx.icon("menu", size=30)
                    ),
                    rx.menu.content(
                        navbar_icons_menu_item("DASHBOARD", "bar_chart", "/dashboard"),
                        navbar_icons_menu_item("ALGO", "bot", "/algo"),
                    ),
                    justify="end",
                ),
                rx.spacer(),
                rx.button("Logout", variant="soft", on_click=rx.redirect("/")),
                justify="between",
                align_items="center",
            ),
        ),
        bg="trasparent",
        padding="1em",
        width="100%",
    )