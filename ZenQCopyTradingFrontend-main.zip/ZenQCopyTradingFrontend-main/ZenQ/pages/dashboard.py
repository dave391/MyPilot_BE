"""The overview page of the app."""

import datetime

import reflex as rx

from .login import FormInputState
# from .login import FormInputState
from .. import styles
from ..components.card import card
from ..config import light_name, investor_name, btc_name, xrp_name
from ..templates import template
from ..views.acquisition_view import acquisition
from ..views.charts import (
    StatsState,
    pie_chart
)
from ..views.stats_cards import stats_cards, stats_card, stats_cards_strategy, stats_cards_mobile


# from .profile import ProfileState

class DashboardState(rx.State):
    todo_field: bool = False

    async def verify_login(self):
        state = await self.get_state(FormInputState)
        if state.user == "":
            yield rx.redirect("/")

@template(route="/dashboard", title="Overview", on_load=StatsState.get_dashboard_data)
def dashboard() -> rx.Component:
    """The overview page.

    Returns:
        The UI for the overview page.

    """
    """The overview page.

    Returns:
        The UI for the overview page.

    """
    return rx.vstack(
        rx.heading(f"Welcome, {FormInputState.user}", size="7"),
        # rx.code(f"""Release 1.3 - Sistemi attivi.""", size="5", color="yellow"),
        # rx.code("AVVISO IMPORTNTE "
        #         "Il  23/01/2025 alle ore 21:00 CET, MyPilot è stato aggiornato alla versione 1.1. "
        #         "Durante il processo, è stato necessario resettare tutti i conti demo. "
        #         "Ti invitiamo a sottoscrivere nuovamente gli ALGO preferiti per continuare a utilizzare la piattaforma al massimo delle sue potenzialità. "
        #         "Grazie per il tuo supporto e buon trading con la nuova versione di MyPilot!",
        #     size="5", color="yellow"),

        rx.desktop_only(
            rx.hstack(
            stats_cards(total_capital=StatsState.capitale_totale, roi=StatsState.roi, pnl=StatsState.pnl, invested_capital=StatsState.invested_capital,
                        best_bot=StatsState.best_performance, active_bot=StatsState.active_bot),
            rx.grid(rx.tooltip(
                card(
                    rx.hstack(
                        rx.hstack(
                            rx.icon("user-round-search", size=20),
                            rx.text("Analisi allocazione", size="4", weight="medium"),
                            align="center",
                            spacing="2",
                        ),
                        # timeframe_select(),
                        align="center",
                        width="100%",
                        justify="between",
                    ),
                    pie_chart(),
                ),
                content="Il grafico indica la suddivisione percentuale tra i vari ALGO, divisi per colori."),
                width="100%",
            ),
                gap="1rem",
                grid_template_columns=[
                    "1fr",
                    "repeat(1, 1fr)",
                    "repeat(2, 1fr)",
                    "repeat(2, 1fr)",
                    "repeat(2, 1fr)",
                ],
                width="105%",
            ),
        ),
        rx.mobile_and_tablet(
                stats_cards_mobile(total_capital=StatsState.capitale_totale, roi=StatsState.roi, pnl=StatsState.pnl,
                            invested_capital=StatsState.invested_capital,
                            best_bot=StatsState.best_performance, active_bot=StatsState.active_bot),

                    card(
                        rx.hstack(
                            rx.hstack(
                                rx.icon("user-round-search", size=20),
                                rx.text("Analisi allocazione", size="4", weight="medium"),
                                align="center",
                                spacing="2",
                            ),
                            # timeframe_select(),
                            align="center",
                            width="100%",
                            justify="between",
                        ),
                        pie_chart(),
                        margin_top="20px"
                    ),
                    width="100%",

                gap="1rem",
                grid_template_columns=[
                    "1fr",
                    "repeat(1, 1fr)",
                    "repeat(2, 1fr)",
                    "repeat(2, 1fr)",
                    "repeat(2, 1fr)",
                ],

        ),
        rx.divider(),
        rx.heading("My Algo"),
        rx.cond(StatsState.light_capital_invested != 0,
        rx.vstack(
            rx.heading(light_name),
            stats_cards_strategy(total_capital=StatsState.light_capital, roi=StatsState.light_capital_roi, pnl=StatsState.light_capital_pnl,
                        invested_capital=StatsState.light_capital_invested, color="blue"),
            width="100%"
        ),),
        rx.cond(StatsState.investor_capital_invested > 0,
        rx.vstack(
        rx.heading(investor_name),
        stats_cards_strategy(total_capital=StatsState.investor_capital, roi=StatsState.investor_capital_roi, pnl=StatsState.investor_capital_pnl,
                    invested_capital=StatsState.investor_capital_invested, color="purple"),
            width="100%"
        ),),
        rx.cond(StatsState.btc_capital_invested > 0,
            rx.vstack(
        rx.heading(btc_name),
        stats_cards_strategy(total_capital=StatsState.btc_capital, roi=StatsState.btc_capital_roi, pnl=StatsState.btc_capital_pnl,
                    invested_capital=StatsState.btc_capital_invested, color="orange"),
                width="100%"
            ),),
                rx.cond(StatsState.xrp_capital_invested > 0,
                rx.vstack(
        rx.heading(xrp_name),
        stats_cards_strategy(total_capital=StatsState.xrp_capital, roi=StatsState.xrp_capital_roi, pnl=StatsState.xrp_capital_pnl,
                    invested_capital=StatsState.xrp_capital_invested, color="yellow"),
                    width="100%"
                ),
                        ),
    rx.box(
        rx.text("Risultati simulati su prezzi reali di mercato.",
            size="4", color="yellow", align="center"),
        align="center",
        width="100%"),

        spacing="8",
        width="100%",
    on_mount=DashboardState.verify_login)

    # return rx.vstack(
    #     rx.box(rx.heading(f"Welcome, {FormInputState.user}", size="8",
    #                       padding_right="1em",
    #                       padding_bottom="1em",
    #                       ), background="red"),
    #              rx.hstack(
    #                  rx.card(
    #                  rx.vstack(
    #                  rx.heading(
    #                  f"Capitale investito: {StatsState.capitale_totale}"
    #                 ),rx.flex(
    #                  rx.heading(
    #                      "PnL:"
    #                  ),rx.text({StatsState.pnl})),
    #                  rx.heading(
    #                      f"ROI: {StatsState.roi}"
    #                  ),
    #                  rx.heading(
    #                      f"APY: {StatsState.apy}"
    #                  ),
    #                  align="start",
    #                  height="100%",
    #                  width="100%",
    #                  background="red"
    #              ),
    # width="100%"),card(
    #             rx.hstack(
    #                 rx.hstack(
    #                     rx.icon("user-round-search", size=20),
    #                     rx.text("Investments Analytics", size="4", weight="medium"),
    #                     align="center",
    #                     spacing="2",
    #                 ),
    #                 align="center",
    #                 width="100%",
    #                 height="100%",
    #                 justify="between",
    #             ),
    #             pie_chart(),
    #         ),
    #                  background="red",
    #                  width="100%"
    #              ),
    #     rx.box(rx.heading("My Algo", size="8"), padding="10px", background="red"),
    #     rx.hstack(
    #         rx.card(
    #             rx.vstack(
    #                 rx.heading(
    #                     light_name
    #                 ),
    #                 rx.text(
    #                     f"Capitale investito: {StatsState.capitale_totale}"
    #                 ),
    #                 rx.text(
    #                     f"PnL:{StatsState.pnl}"
    #                 ),
    #                 rx.text(
    #                     f"ROI: {StatsState.roi}"
    #                 ),
    #                 rx.text(
    #                     f"APY: {StatsState.apy}"
    #                 ),
    #                 align="start",
    #                 height="100%",
    #                 width="100%"
    #             ),
    #             width="100%"),
    #
    #         rx.card(
    #             rx.vstack(
    #                 rx.heading(
    #                     investor_name
    #                 ),
    #                 rx.text(
    #                     f"Capitale investito: {StatsState.capitale_totale}"
    #                 ),
    #                 rx.text(
    #                     f"PnL:{StatsState.pnl}"
    #                 ),
    #                 rx.text(
    #                     f"ROI: {StatsState.roi}"
    #                 ),
    #                 rx.text(
    #                     f"APY: {StatsState.apy}"
    #                 ),
    #                 align="start",
    #                 height="100%",
    #                 width="100%"
    #             ),
    #             width="100%"),
    #         rx.card(
    #             rx.vstack(
    #                 rx.heading(
    #                     btc_name
    #                 ),
    #                 rx.text(
    #                     f"Capitale investito: {StatsState.capitale_totale}"
    #                 ),
    #                 rx.text(
    #                     f"PnL:{StatsState.pnl}"
    #                 ),
    #                 rx.text(
    #                     f"ROI: {StatsState.roi}"
    #                 ),
    #                 rx.text(
    #                     f"APY: {StatsState.apy}"
    #                 ),
    #                 align="start",
    #                 height="100%",
    #                 width="100%"
    #             ),
    #             width="100%"),
    #         rx.card(
    #             rx.vstack(
    #                 rx.heading(
    #                     xrp_name
    #                 ),
    #                 rx.text(
    #                     f"Capitale investito: {StatsState.capitale_totale}"
    #                 ),
    #                 rx.text(
    #                     f"PnL:{StatsState.pnl}"
    #                 ),
    #                 rx.text(
    #                     f"ROI: {StatsState.roi}"
    #                 ),
    #                 rx.text(
    #                     f"APY: {StatsState.apy}"
    #                 ),
    #                 align="start",
    #                 height="100%",
    #                 width="100%"
    #             ),
    #          width="100%"
    #         ),
    #         align="center",
    #             width="100%", spacing="4"),
    #              widht="100%",
    #              backgroung = "red",
    #     on_mount=DashboardState.verify_login
    #              )
    # # return rx.vstack(
    # #     rx.heading(f"Welcome, {ProfileState.profile.name}", size="5"),
    # #     rx.flex(
    # #         rx.input(
    # #             rx.input.slot(rx.icon("search"), padding_left="0"),
    # #             placeholder="Search here...",
    # #             size="3",
    # #             width="100%",
    # #             max_width="450px",
    # #             radius="large",
    # #             style=styles.ghost_input_style,
    # #         ),
    # #         rx.flex(
    # #             spacing="4",
    # #             width="100%",
    # #             wrap="nowrap",
    # #             justify="end",
    # #         ),
    # #         justify="between",
    # #         align="center",
    # #         width="100%",
    # #     ),
    # #     stats_cards(),
    # #     card(
    # #         rx.hstack(
    # #             tab_content_header(),
    # #             rx.segmented_control.root(
    # #                 rx.segmented_control.item("Users", value="users"),
    # #                 rx.segmented_control.item("Revenue", value="revenue"),
    # #                 rx.segmented_control.item("Orders", value="orders"),
    # #                 margin_bottom="1.5em",
    # #                 default_value="users",
    # #                 on_change=StatsState.set_selected_tab,
    # #             ),
    # #             width="100%",
    # #             justify="between",
    # #         ),
    # #         rx.match(
    # #             StatsState.selected_tab,
    # #             ("users", users_chart()),
    # #             ("revenue", revenue_chart()),
    # #             ("orders", orders_chart()),
    # #         ),
    # #     ),
    # #     rx.grid(
    # #         card(
    # #             rx.hstack(
    # #                 rx.hstack(
    # #                     rx.icon("user-round-search", size=20),
    # #                     rx.text("Visitors Analytics", size="4", weight="medium"),
    # #                     align="center",
    # #                     spacing="2",
    # #                 ),
    # #                 timeframe_select(),
    # #                 align="center",
    # #                 width="100%",
    # #                 justify="between",
    # #             ),
    # #             pie_chart(),
    # #         ),
    # #         card(
    # #             rx.hstack(
    # #                 rx.icon("globe", size=20),
    # #                 rx.text("Acquisition Overview", size="4", weight="medium"),
    # #                 align="center",
    # #                 spacing="2",
    # #                 margin_bottom="2.5em",
    # #             ),
    # #             rx.vstack(
    # #                 acquisition(),
    # #             ),
    # #         ),
    # #         gap="1rem",
    # #         grid_template_columns=[
    # #             "1fr",
    # #             "repeat(1, 1fr)",
    # #             "repeat(2, 1fr)",
    # #             "repeat(2, 1fr)",
    # #             "repeat(2, 1fr)",
    # #         ],
    # #         width="100%",
    # #     ),
    # #     spacing="8",
    # #     width="100%",
    # # )
    #
