from .dashboard import dashboard
from .table import table
from .algo import algo
from .light import light
from .investor import investor
from .btc_tc import btc_trend
from .xrp_tc import xrp_trend
from .login import login

__all__ = [ "dashboard", "table", "algo", "light", "investor", "btc_trend", "xrp_trend", "login"]
