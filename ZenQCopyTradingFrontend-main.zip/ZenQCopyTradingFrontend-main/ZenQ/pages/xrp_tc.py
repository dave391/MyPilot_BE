"""The overview page of the app."""

import datetime
import typing

import reflex as rx
import requests
from urllib.parse import quote

from .login import FormInputState
from ..config import xrp_desc, alert_text, xrp_name, base_url, setup_name, setup_desc, disable_buttons
from ..templates import template
from ..views.charts import (
    StatsState,
    xrp_page_chart
)

class XRPState(rx.State):
    form_data: dict = {}
    value: float = 500.0
    stop_loss: float = 0.0
    take_profit: float = 0.0
    is_subscribed: bool = False

    @rx.event
    def set_end(self, value: list[typing.Union[int, float]]):
        self.value = value[0]

    @rx.event
    def handle_submit(self, form_data: dict):
        """Handle the form submit."""
        self.form_data = form_data

    async def subscribe(self):
        # chiamata a backend
        self.value = float(self.value)
        state = await self.get_state(FormInputState)
        if isinstance(self.value, float):
            res = requests.get(
                f"{base_url}/start/{state.user}/{self.value}/4/{self.take_profit}/{self.stop_loss}/{quote(state.password)}/")
            if res.status_code == 200:
                self.set_is_subscribed(True)
                return rx.toast.success(f"Started!", position="bottom-center")
            else:
                return rx.toast.error(f"Servizio al momento non disponibile. Contatta support@zen-q.com per assistenza.", position="bottom-center")

    async def unsubscribe(self):
        # chiamata a backend
        state = await self.get_state(FormInputState)
        res = requests.get(
            f"{base_url}/stop/{state.user}/4")
        if res.status_code == 200:
            self.set_is_subscribed(False)
            return rx.toast.success(f"Stopped!", position="bottom-center")
        else:
            return rx.toast.error(f"Error", position="bottom-center")

    async def verify_login(self):
        state = await self.get_state(FormInputState)
        if state.user == "":
            yield rx.redirect("/")
        else:
            res = requests.get(
                f"{base_url}/get_active/{state.user}/4")
            if res.status_code == 200:
                self.set_is_subscribed(True)
            else:
                self.set_is_subscribed(False)


@template(route="/xrp-trend", title="Algo - XRP Trend Catcher", on_load=StatsState.get_data_strategy_4)
def xrp_trend() -> rx.Component:
    return rx.hstack(
        rx.vstack(
            rx.card(
                rx.heading(xrp_name),
                rx.markdown(xrp_desc),
                width="100%",
            ),
            rx.card(
                rx.heading(setup_name),
                rx.markdown(setup_desc),
                width="100%",
            ),
        ),
        rx.vstack(rx.tooltip(rx.card(
            xrp_page_chart(),
            width="100%",
        ), content="Grafico dell’andamento storico dell’Algo dal primo giorno di utilizzo."),
            rx.hstack(
                rx.tooltip(rx.code(f"Days: {StatsState.xrp_days}", size="5", color_scheme="blue"),
                           content="Numero di giorni dall’inizio della strategia."),
                rx.tooltip(rx.code(f"ROI: {StatsState.xrp_roi}", size="5", color_scheme="blue"),
                           content="Risultato totale della strategia a partire dal primo giorno."),
                rx.tooltip(rx.code(f"Monthly avg: {StatsState.xrp_monthly_avg}", size="5", color_scheme="blue"),
                           content="Risultato medio mensile a partire dal primo giorno."),
                rx.tooltip(rx.code(f"Yearly avg trend: {StatsState.xrp_yearly_trend}", size="5", color_scheme="blue"),
                           content="Risultato medio annuale dell’Algo, entro il primo anno è una proiezione."),
                width="100%"),
            rx.vstack(
                rx.card(
                    rx.vstack(
                        rx.tooltip(
                            rx.box(
                                rx.text("Importo che si desidera investire: ", align="center"),
                                rx.heading(f"{XRPState.value} USDC", align="center", color_scheme="grass"),
                                padding="10px"),
                            content="Gli USDC sono «Stable Coin» ovvero un token che esprime il valore del Dollaro USA. L’asset virtuale meno volatile sul mercato."),
                        align="center",
                        width="100%"),
                    rx.slider(
                        default_value=500,
                        min=200,
                        max=2000,
                        step=50,
                        on_change=XRPState.set_end.throttle(150),
                        padding="10px"
                    ),
                    rx.center(
                        rx.vstack(
                            rx.hstack(
                                rx.tooltip(
                                    rx.input(placeholder="STOP LOSS", width="40%", color_scheme="tomato", type="number",
                                             disabled=True),
                                    content="Attualmente non disponibile."),
                                rx.code("%", color_scheme="tomato", size="4"),
                                width="100%",
                                align="center",
                                justify="center"
                            ),
                            rx.hstack(
                                rx.tooltip(
                                    rx.input(placeholder="TAKE PROFIT", width="40%", color_scheme="green",
                                             disabled=True),
                                    content="Attualmente non disponibile."),
                                rx.code("%", color_scheme="grass", size="4"),
                                width="100%",
                                align="center",
                                justify="center"
                            ),
                            width="70%",
                            margin="15px",
                        ),
                    ), rx.hstack(
                        rx.code(f"Importo: {XRPState.value} USDC", color_scheme="grass", size="3"),
                        rx.code(f"Stop Loss: {XRPState.stop_loss} USDC", color_scheme="tomato", size="3"),
                        rx.code(f"Take profit: {XRPState.take_profit} USDC", color_scheme="grass", size="3"),
                        width="100%",
                        padding="10px"
                    ),
                    rx.cond(XRPState.is_subscribed,
                            rx.alert_dialog.root(
                                rx.alert_dialog.trigger(
                                    rx.button("UNSUBSCRIBE", width="100%", color_scheme="tomato", disabled=disable_buttons),
                                ),
                                rx.alert_dialog.content(
                                    rx.alert_dialog.title("Confermi di voler interrompere l'Algo?"),
                                    rx.flex(
                                        rx.alert_dialog.cancel(
                                            rx.button(
                                                "CANCEL",
                                                variant="soft",
                                                color_scheme="gray",
                                            ),
                                        ),
                                        rx.alert_dialog.action(
                                            rx.button(
                                                "STOP ALGO",
                                                color_scheme="red",
                                                variant="solid",
                                                on_click=XRPState.unsubscribe
                                            ),
                                        ),
                                        spacing="3",
                                        margin_top="16px",
                                        justify="end",
                                    ),
                                    style={"max_width": 450},
                                ),
                            ),
                            rx.button("SUBSCRIBE", width="100%", color_scheme="grass", disabled=disable_buttons,
                                                 on_click=XRPState.subscribe),),
                    width="100%",
                    height="100%",
                    align="center",

                ),
                width="100%",
                height="100%",
                align="center"
            ),
            rx.code(alert_text, size="2", color_scheme="tomato"),
        ),
        width="100%",
        on_mount=XRPState.verify_login
    )
