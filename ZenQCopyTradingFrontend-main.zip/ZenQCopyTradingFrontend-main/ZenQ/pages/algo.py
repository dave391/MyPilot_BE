"""The overview page of the app."""

import reflex as rx
from .login import FormInputState
from ..config import light_name, investor_name, xrp_name, btc_name
from ..templates import template
from ..views.charts import (
    StatsState,
    area_toggle
)
from ..views.stats_cards import algo_light_cards, algo_investor_cards, algo_btc_cards, algo_xrp_cards

class AlgoState(rx.State):
    todo_field: bool = False

    async def verify_login(self):
        state = await self.get_state(FormInputState)
        if state.user == "":
            yield rx.redirect("/")

@template(route="/algo", title="Algo", on_load=StatsState.randomize_data)
def algo() -> rx.Component:
    """The overview page.

    Returns:
        The UI for the overview page.

    """
    return rx.vstack(
        rx.grid(
            algo_light_cards(title=light_name, roi=StatsState.light_roi, tooltip_roi="Risultato percentuale storico fino ad oggi.", yearly_trend=StatsState.light_yearly_trend, tooltip_trend="Risultato medio annuale dell’Algo, entro il primo anno è una proiezione.", deposit=200, tooltip_deposit="Importo minimo per poter lanciare l’Algo indicato.", url="/light"),
            algo_investor_cards(title=investor_name, roi=StatsState.investor_roi, tooltip_roi="Risultato percentuale storico fino ad oggi.", yearly_trend=StatsState.investor_yearly_trend, tooltip_trend="Risultato medio annuale dell’Algo, entro il primo anno è una proiezione.", deposit=200, tooltip_deposit="Importo minimo per poter lanciare l’Algo indicato.", url="/investor"),
            algo_btc_cards(title=btc_name, roi=StatsState.btc_roi, tooltip_roi="Risultato percentuale storico fino ad oggi.", yearly_trend=StatsState.btc_yearly_trend, tooltip_trend="Risultato medio annuale dell’Algo, entro il primo anno è una proiezione.", deposit=200, tooltip_deposit="Importo minimo per poter lanciare l’Algo indicato.", url="/btc-trend"),
            algo_xrp_cards(title=xrp_name, roi=StatsState.xrp_roi, tooltip_roi="Risultato percentuale storico fino ad oggi.", yearly_trend=StatsState.xrp_yearly_trend, tooltip_trend="Risultato medio annuale dell’Algo, entro il primo anno è una proiezione.", deposit=200, tooltip_deposit="Importo minimo per poter lanciare l’Algo indicato.", url="/xrp-trend"),
            gap="1rem",
            grid_template_columns=[
                "1fr",
                "repeat(1, 1fr)",
                "repeat(2, 1fr)",
                "repeat(2, 1fr)",
                "repeat(2, 1fr)",
            ],
            width="100%",
        ),
        spacing="7",
        width="100%",
        on_mount=AlgoState.verify_login
    )
