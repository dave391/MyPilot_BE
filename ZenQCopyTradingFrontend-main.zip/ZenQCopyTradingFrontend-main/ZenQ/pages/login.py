import json

import reflex as rx
from ..templates import template_login
from ..styles import base_style
from ..config import base_url

rx.toast.provider()
import requests
# from fosbury_bot.config import base_url, background, card_light_background, card_dark_background, FONT_FAMILY
from reflex.style import toggle_color_mode

# from fosbury_bot.security import encrypt_fe_key


class FormInputState(rx.State):
    form_data: dict = {}
    user: str = ""
    password: str = ""
    main_account_id: str = ""
    error: str = ""
    valid: bool = True
    is_yet_otp_valid: bool = False

    events: list[str] = []

    async def handle_submit(self, form_data: dict):
        # self.set_user(self.user)
        # self.set_password(self.password)
        # return

        self.form_data = form_data
        self.user = form_data['user']

        self.set_user(form_data['user'])
        self.set_password(form_data['password'])

        try:
            params = {"user": self.user,
                      "password": self.password}
            res = requests.post(f"{base_url}/login/", data=params)
            if res.status_code == 200:
                string_message = res.content.decode('utf-8')
                data = json.loads(string_message)
                if data['code'] == "R200":
                    self.set_valid(True)
                    self.set_main_account_id(data['main_account_id'])
                    return rx.redirect("/dashboard")
                else:
                    self.set_valid(False)
                    return rx.toast.error(f"{data['message'][0]}", position="bottom-center")

            else:
                return rx.toast.error("In questo momento l'app non è disponibile", position="bottom-center")

        except BaseException as e:
            return rx.toast.error("In questo momento l'app non è disponibile.", position="bottom-center")



    def reset_user_state(self):
        self.set_valid(True)
        self.set_user("")

    def reset_password(self):
        return rx.redirect("/resetpassword")


@template_login(route="/", title="MyPilot - Zen-Q", on_load=FormInputState.reset_user_state)
def login() -> rx.Component:
    return rx.center(
        rx.vstack(
            rx.form.root(
                rx.vstack(
                    rx.color_mode_cond(
                        rx.image(src="/logo.svg", height="45px", border_radius="3px"),
                        rx.image(src="/logo_white.svg", height="45px", border_radius="3px"),
                    ),
                    rx.heading("Welcome to Zen-Q My Pilot!", align="center"),
                    rx.text(
                        "Inserisci le tue credenziali Zen-Q",
                        size="3",
                        align="center",
                    ),
                    rx.vstack(
                        rx.input(
                            color_scheme=rx.cond(
                               FormInputState.valid , "iris", "tomato"
                            ),
                            variant=rx.cond(
                                FormInputState.valid, "surface", "soft"
                            ),
                            name="user",
                            placeholder="User",
                            type="user",
                            required=True,
                            width="90%",
                            align="center",
                            on_click=FormInputState.reset_user_state
                        ),
                        rx.input(
                            color_scheme=rx.cond(
                                FormInputState.valid, "iris", "tomato"
                            ),
                            variant=rx.cond(
                                FormInputState.valid, "surface", "soft"
                            ),
                            name="password",
                            placeholder="Password",
                            type="password",
                            required=True,
                            width="90%",
                            align="center",
                            on_click=FormInputState.reset_user_state
                        ),
                        width="100%",
                        align="center"
                    ),
                    rx.spacer(),
                    rx.divider(width="70%"),
                    rx.spacer(),
                    rx.button("Login", type="submit", width="90%", align="center"),
                    rx.spacer(),
                    rx.text("Non hai ancora un account Zen-Q demo?"),
                    rx.link(
                            rx.text("Registrati qui"),
                            href="https://demo.zen-q.com/TradingPortal/sign-in"),
                    align="center",
                    spacing="2",
                ),
                on_submit=FormInputState.handle_submit,
                reset_on_submit=False,
                width="100%",
            ),

            # rx.button(rx.icon("sun-moon", size=15),
            #           "Switch to dark mode.", size="1", variant="surface",
            #           on_click=rx.toast.error("Temporary disabled dark mode", position="bottom-center"),
            #           ),

            width="25em",
            # background_color=rx.color_mode_cond(
            #     light=card_light_background, dark=card_dark_background
            # ),
            padding="2em",
            align="center",
            border_radius="0.5em",
            box_shadow="rgba(0, 0, 0, 0.15) 0px 3px 12px",
            border=rx.color_mode_cond(light="1px solid #dddfe5", dark="1px solid #323843"),
            background_color=base_style['background']

        ),
        width="100%",
        height="100vh",
        background="url('/wallpaper.png')",
    )
