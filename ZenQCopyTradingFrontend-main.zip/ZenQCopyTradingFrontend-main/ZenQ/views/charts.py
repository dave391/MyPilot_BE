import json
import requests
import reflex as rx
from reflex.components.radix.themes.base import (
    LiteralAccentColor,
)
from ZenQ.config import base_url, xrp_name, btc_name, investor_name, light_name
from ZenQ.pages.login import FormInputState


class StatsState(rx.State):
    area_toggle: bool = True
    selected_tab: str = "users"
    timeframe: str = "Monthly"
    users_data = []
    revenue_data = []
    orders_data = []
    device_data = []
    pie_chart_data = []

    light_strategy_graph = []
    light_roi: str = ""
    light_monthly_avg: str = ""
    light_yearly_trend: str = ""
    light_days: str = ""


    investor_strategy_graph = []
    investor_roi: str = ""
    investor_monthly_avg: str = ""
    investor_yearly_trend: str = ""
    investor_days: str = ""

    btc_strategy_graph = []
    btc_roi: str = ""
    btc_monthly_avg: str = ""
    btc_yearly_trend: str = ""
    btc_days: str = ""

    xrp_strategy_graph = []
    xrp_roi: str = ""
    xrp_monthly_avg: str = ""
    xrp_yearly_trend: str = ""
    xrp_days: str = ""

    balance: float = 0.0

    capitale_totale : float = 0.0
    invested_capital : float = 0.0
    pnl: float = 0.0
    roi: float = 0.0

    light_capital_invested : float = 0.0
    light_capital : float = 0.0
    light_capital_roi: float = 0
    light_capital_pnl : float = 0.0
    investor_capital_invested : float = 0.0
    investor_capital : float = 0.0
    investor_capital_roi : float = 0.0
    investor_capital_pnl : float = 0.0
    btc_capital_invested : float = 0.0
    btc_capital : float = 0.0
    btc_capital_roi : float = 0.0
    btc_capital_pnl : float = 0.0
    xrp_capital_invested : float = 0.0
    xrp_capital : float = 0.0
    xrp_capital_roi : float = 0.0
    xrp_capital_pnl : float = 0.0
    active_bot : float = 0.0
    best_performance = ""


    def toggle_areachart(self):
        self.area_toggle = not self.area_toggle

    async def get_data_strategy_1(self):
        if self.light_strategy_graph:
            return
        res = requests.get(f"{base_url}/get_performance_graph/1")
        if res.status_code == 200:
            string_message = res.content.decode('utf-8')
            data = json.loads(string_message)
            self.light_strategy_graph = data

    async def get_data_strategy_2(self):
        if self.investor_strategy_graph:
            return
        res = requests.get(f"{base_url}/get_performance_graph/2")
        if res.status_code == 200:
            string_message = res.content.decode('utf-8')
            data = json.loads(string_message)
            self.investor_strategy_graph = data

    async def get_data_strategy_3(self):
        if self.btc_strategy_graph:
            return
        res = requests.get(f"{base_url}/get_performance_graph/3")
        if res.status_code == 200:
            string_message = res.content.decode('utf-8')
            data = json.loads(string_message)
            self.btc_strategy_graph = data

    async def get_data_strategy_4(self):
        if self.xrp_strategy_graph:
            return
        res = requests.get(f"{base_url}/get_performance_graph/4")
        if res.status_code == 200:
            string_message = res.content.decode('utf-8')
            data = json.loads(string_message)
            self.xrp_strategy_graph = data

    async def get_dashboard_data(self):
        state = await self.get_state(FormInputState)
        # if self.pie_chart_data:
        #     return
        res = requests.get(f"{base_url}/get_user_data/{state.user}") # /get_active/{user}/{strategy}
        if res.status_code == 200:
            string_message = res.content.decode('utf-8')
            data = json.loads(string_message)
            self.pie_chart_data = data['pie_chart']
            self.set_capitale_totale(round(data['total_capital'],2))
            self.set_pnl(round(data['pnl'],2))
            self.set_roi(round(data['roi'],2))
            self.set_invested_capital(round(data['invested_capital'],2))
            self.set_light_capital_invested(round(data['light_capital_invested'],2))
            self.set_light_capital(round(data['light_capital'],2))
            self.set_light_capital_roi(round(data['light_capital_roi'],2))
            self.set_light_capital_pnl(round(data['light_capital_pnl'],2))

            self.set_investor_capital_invested(round(data['investor_capital_invested'],2))
            self.set_investor_capital(round(data['investor_capital'],2))
            self.set_investor_capital_roi(round(data['investor_capital_roi'], 2))
            self.set_investor_capital_pnl(round(data['investor_capital_pnl'],2))

            self.set_btc_capital_invested(round(data['btc_capital_invested'],2))
            self.set_btc_capital(round(data['btc_capital'],2))
            self.set_btc_capital_roi(round(data['btc_capital_roi'],2))
            self.set_btc_capital_pnl(round(data['btc_capital_pnl'],2))

            self.set_xrp_capital_invested(round(data['xrp_capital_invested'],2))
            self.set_xrp_capital(round(data['xrp_capital'],2))
            self.set_xrp_capital_roi(round(data['xrp_capital_roi'],2))
            self.set_xrp_capital_pnl(round(data['xrp_capital_pnl'],2))

            res = requests.get(f"{base_url}/get_active/{state.user}")
            if res.status_code == 200:
                string_message = res.content.decode('utf-8')
                data = json.loads(string_message)
                self.active_bot = data
                nome = "Nessun Algo"
                if data > 0:
                    nome = "Da definire"
                    if self.xrp_capital_roi > 0:
                        nome = xrp_name
                    if self.btc_capital_roi > self.xrp_capital_roi:
                        nome = btc_name
                    if self.investor_capital_roi > self.btc_capital_roi:
                        nome = investor_name
                    if self.light_capital_roi > self.investor_capital_roi:
                        nome = light_name

                self.set_best_performance(nome)

    async def get_minor_data(self):
        res = requests.get(f"{base_url}/get_performance_number")
        if res.status_code == 200:
            string_message = res.content.decode('utf-8')
            data = json.loads(string_message)

            self.light_roi = data['1']['ROI']
            self.light_monthly_avg = data['1']['Monthly Avg']
            self.light_yearly_trend = data['1']['Yearly Trend']
            self.light_days = data['1']['Days']

            self.investor_roi = data['2']['ROI']
            self.investor_monthly_avg = data['2']['Monthly Avg']
            self.investor_yearly_trend = data['2']['Yearly Trend']
            self.investor_days = data['2']['Days']

            self.btc_roi = data['3']['ROI']
            self.btc_monthly_avg = data['3']['Monthly Avg']
            self.btc_yearly_trend = data['3']['Yearly Trend']
            self.btc_days = data['3']['Days']

            self.xrp_roi = data['4']['ROI']
            self.xrp_monthly_avg = data['4']['Monthly Avg']
            self.xrp_yearly_trend = data['4']['Yearly Trend']
            self.xrp_days = data['4']['Days']


    async def randomize_data(self):
        # If data is already populated, don't randomize
        if self.light_strategy_graph:
            return

        await self.get_minor_data()
        await self.get_data_strategy_4()
        await self.get_data_strategy_3()
        await self.get_data_strategy_2()
        await self.get_data_strategy_1()


def area_toggle() -> rx.Component:
    return rx.cond(
        StatsState.area_toggle,
        rx.icon_button(
            rx.icon("area-chart"),
            size="2",
            cursor="pointer",
            variant="surface",
            on_click=StatsState.toggle_areachart,
        ),
        rx.icon_button(
            rx.icon("bar-chart-3"),
            size="2",
            cursor="pointer",
            variant="surface",
            on_click=StatsState.toggle_areachart,
        ),
    )


def _create_gradient(color: LiteralAccentColor, id: str) -> rx.Component:
    return (
        rx.el.svg.defs(
            rx.el.svg.linear_gradient(
                rx.el.svg.stop(
                    stop_color=rx.color(color, 7), offset="5%", stop_opacity=0.8
                ),
                rx.el.svg.stop(
                    stop_color=rx.color(color, 7), offset="95%", stop_opacity=0
                ),
                x1=0,
                x2=0,
                y1=0,
                y2=1,
                id=id,
            ),
        ),
    )


def _custom_tooltip(color: LiteralAccentColor) -> rx.Component:
    return (
        rx.recharts.graphing_tooltip(
            separator=" : ",
            content_style={
                "backgroundColor": rx.color("gray", 1),
                "borderRadius": "var(--radius-2)",
                "borderWidth": "1px",
                "borderColor": rx.color(color, 7),
                "padding": "0.5rem",
                "boxShadow": "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
            },
            is_animation_active=True,
        ),
    )


def light_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            _custom_tooltip("green"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            rx.recharts.x_axis(data_key="time", scale="auto", tick_count=5),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            data=StatsState.light_strategy_graph,
            height=300,
        )

def investor_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            _custom_tooltip("green"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            rx.recharts.x_axis(data_key="time", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            data=StatsState.investor_strategy_graph,
            height=300,
        )

def btc_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            _custom_tooltip("green"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            rx.recharts.x_axis(data_key="time", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            data=StatsState.btc_strategy_graph,
            height=300,
        )

def xrp_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            _custom_tooltip("green"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            rx.recharts.x_axis(data_key="time", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            data=StatsState.xrp_strategy_graph,
            height=300,
        )

def orders_chart() -> rx.Component:
    return rx.cond(
        StatsState.area_toggle,
        rx.recharts.area_chart(
            _create_gradient("purple", "colorPurple"),
            _custom_tooltip("purple"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="Orders",
                stroke=rx.color("purple", 9),
                fill="url(#colorPurple)",
                type_="monotone",
            ),
            rx.recharts.x_axis(data_key="Date", scale="auto"),
            rx.recharts.y_axis(),
            rx.recharts.legend(),
            data=StatsState.orders_data,
            height=425,
        ),
        rx.recharts.bar_chart(
            _custom_tooltip("purple"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.bar(
                data_key="Orders",
                stroke=rx.color("purple", 9),
                fill=rx.color("purple", 7),
            ),
            rx.recharts.x_axis(data_key="Date", scale="auto"),
            rx.recharts.y_axis(),
            rx.recharts.legend(),
            data=StatsState.orders_data,
            height=425,
        ),
    )


def pie_chart() -> rx.Component:
    return rx.recharts.pie_chart(
            rx.recharts.pie(
                data=StatsState.pie_chart_data,
                data_key="value",
                name_key="name",
                cx="50%",
                cy="50%",
                padding_angle=1,
                inner_radius="70",
                outer_radius="100",
                label=True,
            ),
            rx.recharts.legend(),
            height=283,
        )


def timeframe_select() -> rx.Component:
    return rx.select(
        ["Monthly", "Yearly"],
        default_value="Monthly",
        value=StatsState.timeframe,
        variant="surface",
        on_change=StatsState.set_timeframe,
    )

def light_algo_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            # _custom_tooltip("blue"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            # rx.recharts.x_axis(data_key="Date", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            # rx.recharts.legend(),
            data=StatsState.light_strategy_graph,
            # height="40%",
            # width="60%",
        )

def investor_algo_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            # _custom_tooltip("blue"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            # rx.recharts.x_axis(data_key="Date", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            # rx.recharts.legend(),
            data=StatsState.investor_strategy_graph,
            # height="40%",
            # width="60%",
        )
def btc_algo_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            # _custom_tooltip("blue"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            # rx.recharts.x_axis(data_key="Date", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            # rx.recharts.legend(),
            data=StatsState.btc_strategy_graph,
            # height="40%",
            # width="60%",
        )
def xrp_algo_page_chart() -> rx.Component:
    return rx.recharts.area_chart(
            _create_gradient("blue", "colorBlue"),
            # _custom_tooltip("blue"),
            rx.recharts.cartesian_grid(
                stroke_dasharray="3 3",
            ),
            rx.recharts.area(
                data_key="quoteQty",
                stroke=rx.color("blue", 9),
                fill="url(#colorBlue)",
                type_="monotone",
            ),
            # rx.recharts.x_axis(data_key="Date", scale="auto"),
            rx.recharts.y_axis(domain=[1000, "auto"]),
            # rx.recharts.legend(),
            data=StatsState.xrp_strategy_graph,
            # height="40%",
            # width="60%",
        )