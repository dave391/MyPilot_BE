import reflex as rx
from reflex.components.radix.themes.base import LiteralAccentColor
from .charts import light_algo_page_chart, investor_algo_page_chart, btc_algo_page_chart, xrp_algo_page_chart
from .. import styles

def stats_card(
    stat_name: str,
    value: float,
    icon: str,
    icon_color: LiteralAccentColor,
    extra_char: str = "",
    tooltip_value: str = "",
) -> rx.Component:

    return rx.tooltip(
        rx.card(
        rx.vstack(
            rx.hstack(
                rx.badge(
                    rx.icon(tag=icon, size=34),
                    color_scheme=icon_color,
                    radius="full",
                    padding="0.7rem",
                ),
                rx.vstack(
                    rx.heading(
                        f"{extra_char}{value}",
                        size="6",
                        weight="bold",
                    ),
                    rx.text(stat_name, size="4", weight="medium"),
                    spacing="1",
                    height="100%",
                    align_items="start",
                    width="100%",
                ),
                height="100%",
                spacing="4",
                align="center",
                width="100%",
            ),

            spacing="3",
        ),
        size="3",
        width="100%",
        box_shadow=styles.box_shadow_style,
    ),
        content=tooltip_value)

def stats_card_text(
    stat_name: str,
    value: str,
    icon: str,
    icon_color: LiteralAccentColor,
    extra_char: str = "",
        tooltip_value: str = ""
) -> rx.Component:

    return rx.tooltip(rx.card(
        rx.vstack(
            rx.hstack(
                rx.badge(
                    rx.icon(tag=icon, size=34),
                    color_scheme=icon_color,
                    radius="full",
                    padding="0.7rem",
                ),
                rx.vstack(
                    rx.heading(
                        f"{value}",
                        size="6",
                        weight="bold",
                    ),
                    rx.text(stat_name, size="4", weight="medium"),
                    spacing="1",
                    height="100%",
                    align_items="start",
                    width="100%",
                ),
                height="100%",
                spacing="4",
                align="center",
                width="100%",
            ),

            spacing="3",
        ),
        size="3",
        width="100%",
        box_shadow=styles.box_shadow_style,
    ),
        content=tooltip_value)

def stats_card_text_active_bot(
    stat_name: str,
    value: str,
    icon: str,
    icon_color: LiteralAccentColor,
    extra_char: str = "",
    tooltip_value: str = ""
) -> rx.Component:

    return rx.tooltip(
        rx.card(
        rx.vstack(
            rx.hstack(
                rx.badge(
                    rx.icon(tag=icon, size=34),
                    color_scheme=icon_color,
                    radius="full",
                    padding="0.7rem",
                ),
                rx.vstack(
                    rx.heading(
                        f"{value}/4",
                        size="6",
                        weight="bold",
                    ),
                    rx.text(stat_name, size="4", weight="medium"),
                    spacing="1",
                    height="100%",
                    align_items="start",
                    width="100%",
                ),
                height="100%",
                spacing="4",
                align="center",
                width="100%",
            ),

            spacing="3",
        ),
        size="3",
        width="100%",
        box_shadow=styles.box_shadow_style,
    ),
        content=tooltip_value)

def stats_cards_mobile(total_capital, roi, pnl, invested_capital, best_bot, active_bot) -> rx.Component:
    return rx.grid(
        stats_card(
            stat_name="Totale portafoglio",
            value=invested_capital,
            icon="coins",
            icon_color="green",
            extra_char="$ ",
            tooltip_value="Valore totale del portafoglio di tutti gli Algo in USD."
        ),
        stats_card(
            stat_name="Allocazione",
            value=total_capital,
            icon="wallet",
            icon_color="green",
            extra_char="$ ",
            tooltip_value="Importo totale dedicato agli Algo."
        ),
        stats_card(
            stat_name="PnL",
            value=pnl,
            icon="hand-coins",
            icon_color="green",
            extra_char="$ ",
            tooltip_value="RIsultato cumulativo in Dollari su tutti gli Algo."
        ),

        stats_card(
            stat_name="ROI",
            value=roi,
            icon="chart-no-axes-combined",
            icon_color="green",
            extra_char="%",
            tooltip_value="% di risultato sul valore totale degli Algo sottoscritti."
        ),
                stats_card_text(
                    stat_name="Algo migliore",
                    value=best_bot,
                    icon="target",
                    icon_color="green",
                    tooltip_value="L’algoritmo che vi sta dando il miglior risultato."
                ),

                stats_card_text_active_bot(
                    stat_name="Algo attivi",
                    value=active_bot,
                    icon="bot",
                    icon_color="green",
                    tooltip_value="Numero di Algoritmi attivi selezionati."
                ),
        gap="1rem",
        grid_template_columns=[
            "1fr",
            "repeat(1, 1fr)",
            "repeat(2, 1fr)",
            "repeat(3, 1fr)",
            "repeat(4, 1fr)",
        ],
        width="100%",

        )


def stats_cards(total_capital, roi, pnl, invested_capital, best_bot, active_bot) -> rx.Component:
    return rx.grid(
        rx.vstack(
            rx.hstack(
        stats_card(
            stat_name="Totale allocato",
            value=invested_capital,
            icon="coins",
            icon_color="green",
            extra_char="USDC ",
            tooltip_value="Importo totale dedicato agli Algo."
        ),
        stats_card(
            stat_name="Totale portafoglio",
            value=total_capital,
            icon="wallet",
            icon_color="green",
            extra_char="$ ",
            tooltip_value="Valore totale del portafoglio di tutti gli Algo in USD."
        ),
                width="100%",
            ),
            rx.hstack(
        stats_card(
            stat_name="PnL",
            value=pnl,
            icon="hand-coins",
            icon_color="green",
            extra_char="$ ",
            tooltip_value="RIsultato cumulativo in Dollari su tutti gli Algo."
        ),

        stats_card(
            stat_name="ROI",
            value=roi,
            icon="chart-no-axes-combined",
            icon_color="green",
            extra_char="%",
            tooltip_value="% di risultato sul valore totale degli Algo sottoscritti."
        ),
                width="100%",
            ),
            rx.hstack(
                stats_card_text(
                    stat_name="Algo migliore",
                    value=best_bot,
                    icon="target",
                    icon_color="green",
                    tooltip_value="L’algoritmo che vi sta dando il miglior risultato."
                ),

                stats_card_text_active_bot(
                    stat_name="Algo attivi",
                    value=active_bot,
                    icon="bot",
                    icon_color="green",
                    tooltip_value="Numero di Algoritmi attivi selezionati."
                ),
                width="100%",
            ),
        gap="1rem",
        grid_template_columns=[
            "1fr",
            "repeat(1, 1fr)",
            "repeat(2, 1fr)",
            "repeat(3, 1fr)",
            "repeat(4, 1fr)",
        ],
        width="100%",

        ),width="100%",
    )

def stats_cards_strategy(total_capital, roi, pnl, invested_capital, color) -> rx.Component:
    return rx.grid(
        stats_card(
            stat_name="Totale allocato",
            value=invested_capital,
            icon="coins",
            icon_color=color,
            extra_char="USDC ",
            tooltip_value="Importo dedicato all’Algo."
        ),
        stats_card(
            stat_name="Valore Algo",
            value=total_capital,
            icon="wallet",
            icon_color=color,
            extra_char="$ ",
            tooltip_value="Valore attuale dell’Algo."
        ),

        stats_card(
            stat_name="PnL",
            value=pnl,
            icon="hand-coins",
            icon_color=color,
            extra_char="$ ",
            tooltip_value="Risultato in Dollari dall’inizio dell’Algo."
        ),

        stats_card(
            stat_name="ROI",
            value=roi,
            icon="chart-no-axes-combined",
            icon_color=color,
            extra_char="%",
            tooltip_value="% di risultato dell’Algo sul valore iniziale."
        ),

        gap="1rem",
        grid_template_columns=[
            "1fr",
            "repeat(1, 1fr)",
            "repeat(2, 1fr)",
            "repeat(3, 1fr)",
            "repeat(4, 1fr)",
        ],
        width="100%",
    )

def algo_light_cards(title: str, roi: str, tooltip_roi: str, yearly_trend: str, tooltip_trend: str, deposit: int, tooltip_deposit: str, url: str) -> rx.Component:
    return rx.link(
        rx.card(
rx.heading(title,
           align="center",
           margin="1em"),
            rx.hstack(
                rx.tooltip(rx.text(f"ROI: {roi}",
                                 align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_roi),
                      rx.spacer(),
                rx.tooltip(rx.text(f"Trend medio annuale: {yearly_trend}",
                        align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_trend),
                      width="100%",
                      ),
            rx.hstack(
            rx.tooltip(rx.text(f"Allocazione minima: {deposit} USDC",
                    align="center",
                    size="3", padding="10px",
           color="white"), content=tooltip_deposit),
                rx.spacer(),
            rx.tooltip(rx.code("LONG",
                    align="center",
                    size="3", padding="10px"), content="si riferisce ad un Algo che compra e rivende successivamente, non effettua operazioni al ribasso, non usa leva."),
                width="100%",
            ),
        rx.box(light_algo_page_chart(),
               align="center",
               padding="10px"
               ),
            rx.hstack(
                rx.tooltip(rx.button("SCOPRI",
                          variant="soft",
                          align="center",
                          width="100%", on_click=rx.redirect(url)),content="Clicca qui per saperne di più."),
                width="100%",
                justify="center",
                align="center"),
        align="center",
        # spacing="4",
        margin_bottom="2.5em",
        ),
        on_click=rx.redirect(url)
    )

def algo_investor_cards(title: str, roi: str, tooltip_roi: str, yearly_trend: str, tooltip_trend: str, deposit: int, tooltip_deposit: str, url: str) -> rx.Component:
    return rx.link(
        rx.card(
rx.heading(title,
           align="center",
           margin="1em"),
            rx.hstack(
                rx.tooltip(rx.text(f"ROI: {roi}",
                                 align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_roi),
                      rx.spacer(),
                rx.tooltip(rx.text(f"Trend medio annuale: {yearly_trend}",
                        align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_trend),
                      width="100%",
                      ),
            rx.hstack(
            rx.tooltip(rx.text(f"Allocazione minima: {deposit} USDC",
                    align="center",
                    size="3", padding="10px",
           color="white"), content=tooltip_deposit),
                rx.spacer(),
            rx.tooltip(rx.code("LONG",
                    align="center",
                    size="3", padding="10px"), content="si riferisce ad un Algo che compra e rivende successivamente, non effettua operazioni al ribasso, non usa leva."),
                width="100%",
            ),

        rx.box(investor_algo_page_chart(),
               align="center",
               padding="10px"
               ),
            rx.hstack(
                rx.tooltip(rx.button("SCOPRI",
                          variant="soft",
                          align="center",
                          width="100%", on_click=rx.redirect(url)),content="Clicca qui per saperne di più."),
                width="100%",
                justify="center",
                align="center"),
        align="center",
        # spacing="4",
        margin_bottom="2.5em",
        ),
        on_click=rx.redirect(url)
    )

def algo_btc_cards(title: str, roi: str, tooltip_roi: str, yearly_trend: str, tooltip_trend: str, deposit: int, tooltip_deposit: str, url: str) -> rx.Component:
    return rx.link(
        rx.card(
rx.heading(title,
           align="center",
           margin="1em"),
            rx.hstack(
                rx.tooltip(rx.text(f"ROI: {roi}",
                                 align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_roi),
                      rx.spacer(),
                rx.tooltip(rx.text(f"Trend medio annuale: {yearly_trend}",
                        align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_trend),
                      width="100%",
                      ),
            rx.hstack(
            rx.tooltip(rx.text(f"Allocazione minima: {deposit} USDC",
                    align="center",
                    size="3", padding="10px",
           color="white"), content=tooltip_deposit),
                rx.spacer(),
            rx.tooltip(rx.code("LONG",
                    align="center",
                    size="3", padding="10px"),content="si riferisce ad un Algo che compra e rivende successivamente, non effettua operazioni al ribasso, non usa leva."),
                width="100%",
            ),

        rx.box(btc_algo_page_chart(),
               align="center",
               padding="10px"
               ),
            rx.hstack(
                rx.tooltip(rx.button("SCOPRI",
                          variant="soft",
                          align="center",
                          width="100%", on_click=rx.redirect(url)),content="Clicca qui per saperne di più."),
                width="100%",
                justify="center",
                align="center"),
        align="center",
        # spacing="4",
        margin_bottom="2.5em",
        ),
        on_click=rx.redirect(url)
    )

def algo_xrp_cards(title: str, roi: str, tooltip_roi: str, yearly_trend: str, tooltip_trend: str, deposit: int, tooltip_deposit: str, url: str) -> rx.Component:
    return rx.link(
        rx.card(
rx.heading(title,
           align="center",
           margin="1em"),
            rx.hstack(
                rx.tooltip(rx.text(f"ROI: {roi}",
                                 align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_roi),
                      rx.spacer(),
                rx.tooltip(rx.text(f"Trend medio annuale: {yearly_trend}",
                        align="center",
                        size="5", padding="10px",
           color="white"), content=tooltip_trend),
                      width="100%",
                      ),
            rx.hstack(
            rx.tooltip(rx.text(f"Allocazione minima: {deposit} USDC",
                    align="center",
                    size="3", padding="10px",
           color="white"), content=tooltip_deposit),
                rx.spacer(),
            rx.tooltip(rx.code("LONG",
                    align="center",
                    size="3", padding="10px"),content="si riferisce ad un Algo che compra e rivende successivamente, non effettua operazioni al ribasso, non usa leva."),
                width="100%",
            ),
        rx.box(xrp_algo_page_chart(),
               align="center",
               padding="10px"
               ),
        rx.hstack(
            rx.tooltip(rx.button("SCOPRI",
                      variant="soft",
                      align="center",
                      width="100%", on_click=rx.redirect(url)),content="Clicca qui per saperne di più."),
            width="100%",
            justify="center",
            align="center"),
        align="center",
        # spacing="4",
        margin_bottom="2.5em",
        ),
        on_click=rx.redirect(url)
    )